import 'package:flutter_bloc/flutter_bloc.dart';
import '../../data/datasources/invoice_remote_data_source.dart';
import '../../data/models/invoice_model.dart';
import 'invoice_state.dart';

class InvoiceCubit extends Cubit<InvoiceState> {
  final InvoiceRemoteDataSource _dataSource;

  InvoiceCubit(this._dataSource) : super(InvoiceInitial());

  // 1. Kullanıcının Tüm Faturalarını Çekme
  Future<void> fetchMyInvoices() async {
    emit(InvoiceLoading());
    try {
      final invoices = await _dataSource.getMyInvoices();
      emit(InvoiceLoaded(invoices: invoices));
    } catch (e) {
      emit(InvoiceError('Faturalar yüklenirken hata oluştu: ${e.toString()}'));
    }
  }

  // 2. ID'ye Göre Tek Fatura Detayı Çekme
  Future<void> fetchInvoiceById(int id) async {
    emit(InvoiceLoading());
    try {
      final invoice = await _dataSource.getInvoiceById(id);
      emit(InvoiceLoaded(invoices: [invoice], selectedInvoice: invoice));
    } catch (e) {
      emit(InvoiceError('Fatura detayı alınamadı (ID: $id): ${e.toString()}'));
    }
  }

  // 3. Yeni Fatura Ekleme (DÜZELTİLDİ)
  Future<void> createInvoice(InvoiceModel invoice) async {
    // Mevcut ekranda yüklü olan fatura listesini sakla
    List<InvoiceModel> currentList = [];
    if (state is InvoiceLoaded) {
      currentList = List.from((state as InvoiceLoaded).invoices);
    }

    try {
      // 1. Backend'e fatura ekleme isteği at
      await _dataSource.createInvoice(invoice);
      
      // 2. Yeni faturayı listenin en başına ekle ve ekranı güncelle
      currentList.insert(0, invoice);
      emit(InvoiceLoaded(invoices: currentList));
    } catch (e) {
      emit(InvoiceError('Fatura eklenirken hata oluştu: ${e.toString()}'));
    }
  }
}