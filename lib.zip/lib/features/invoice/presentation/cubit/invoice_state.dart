// lib/features/invoice/presentation/cubit/invoice_state.dart

import '../../data/models/invoice_model.dart';

abstract class InvoiceState {}

class InvoiceInitial extends InvoiceState {}

class InvoiceLoading extends InvoiceState {}

class InvoiceLoaded extends InvoiceState {
  final List<InvoiceModel> invoices;
  final InvoiceModel? selectedInvoice;

  InvoiceLoaded({required this.invoices, this.selectedInvoice});
}

class InvoiceError extends InvoiceState {
  final String message;

  InvoiceError(this.message);
}