import 'dart:convert';
import 'package:dio/dio.dart';
import '../../../../core/network/dio_client.dart';
import '../models/invoice_model.dart';

class InvoiceRemoteDataSource {
  final DioClient _dioClient;

  InvoiceRemoteDataSource(this._dioClient);

  // 1. Faturaları Getir (/api/Invoice)
  Future<List<InvoiceModel>> getMyInvoices() async {
    try {
      final response = await _dioClient.get('Invoice');

      if (response.data is List) {
        return (response.data as List)
            .map((e) => InvoiceModel.fromJson(e as Map<String, dynamic>))
            .toList();
      }

      return [];
    } on DioException catch (e) {
      print("========== GET ERROR ==========");
      print("Status Code: ${e.response?.statusCode}");
      print("Response: ${e.response?.data}");
      print("===============================");
      rethrow;
    }
  }

  // 2. Tek Fatura Getir (/api/Invoice/{id})
  Future<InvoiceModel> getInvoiceById(int id) async {
    try {
      final response = await _dioClient.get('Invoice/$id');
      return InvoiceModel.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      print("========== GET BY ID ERROR ==========");
      print("Status Code: ${e.response?.statusCode}");
      print("Response: ${e.response?.data}");
      print("=====================================");
      rethrow;
    }
  }

  // 3. Fatura Ekle (/api/Invoice)
  Future<void> createInvoice(InvoiceModel invoice) async {
    try {
      final payload = invoice.toJson();

      print("========== GÖNDERİLEN JSON ==========");
      print(jsonEncode(payload));
      print("=====================================");

      final response = await _dioClient.post(
        'Invoice',
        data: payload,
      );

      print("POST SUCCESS");
      print(response.data);
    } on DioException catch (e) {
      print("========== POST ERROR ==========");
      print("Status Code: ${e.response?.statusCode}");
      print("Response Data: ${e.response?.data}");
      print("Request Data: ${jsonEncode(invoice.toJson())}");
      print("================================");
      rethrow;
    }
  }
}